import { CoinCard } from "@/components/coin-card"
import { Header } from "@/components/header"

export default function Home() {
  const coinPackages = [
    { amount: "1M", price: 10 },
    { amount: "2M", price: 20 },
    { amount: "5M", price: 50 },
    { amount: "10M", price: 100 },
    { amount: "15M", price: 150 },
    { amount: "20M", price: 200 },
    { amount: "30M", price: 300 },
    { amount: "40M", price: 400 },
    { amount: "50M", price: 500 },
  ]

  return (
    <main className="min-h-screen bg-gradient-to-b from-cream-light to-cream">
      <Header />
      <div className="container mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold text-center mb-8 text-purple-dark">Choose Your Coin Package</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {coinPackages.map((pkg) => (
            <CoinCard key={pkg.amount} amount={pkg.amount} price={pkg.price} />
          ))}
        </div>
      </div>
    </main>
  )
}

