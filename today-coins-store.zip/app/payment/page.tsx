"use client"

import { useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { Header } from "@/components/header"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Copy, ExternalLink } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"

export default function PaymentPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const [amount, setAmount] = useState("")
  const [price, setPrice] = useState(0)
  const [selectedMethod, setSelectedMethod] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [showDiscord, setShowDiscord] = useState(false)
  const [discordInvite, setDiscordInvite] = useState("https://discord.gg/todaycoins")
  const [isLoadingInvite, setIsLoadingInvite] = useState(false)

  useEffect(() => {
    const amountParam = searchParams.get("amount")
    const priceParam = searchParams.get("price")

    if (amountParam) setAmount(amountParam)
    if (priceParam) setPrice(Number(priceParam))
  }, [searchParams])

  // Function to fetch Discord invite from our secure API route
  const fetchDiscordInvite = async () => {
    try {
      setIsLoadingInvite(true)
      const response = await fetch("/api/discord-invite")
      const data = await response.json()

      if (data.inviteLink) {
        setDiscordInvite(data.inviteLink)
      }
    } catch (error) {
      console.error("Failed to fetch Discord invite:", error)
      // Keep the default invite link if there's an error
    } finally {
      setIsLoadingInvite(false)
    }
  }

  const handlePayment = () => {
    if (!selectedMethod) return

    setIsProcessing(true)
    // Fetch the Discord invite when payment is completed
    fetchDiscordInvite().then(() => {
      setIsProcessing(false)
      setShowDiscord(true)
    })
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied to clipboard",
      description: "Discord invite link has been copied to your clipboard.",
    })
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-cream-light to-cream">
      <Header />
      <div className="container mx-auto px-4 py-12">
        <Button variant="outline" className="mb-6" onClick={() => router.back()} disabled={isProcessing}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back
        </Button>

        {showDiscord ? (
          <Card className="max-w-md mx-auto animate-glow bg-cream-light">
            <CardHeader className="bg-gradient-to-r from-purple to-purple-dark text-cream">
              <CardTitle className="text-center">Join Our Discord Server</CardTitle>
              <CardDescription className="text-center text-cream-light">
                Complete your purchase of {amount} coins for Rs {price}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex flex-col space-y-4">
                <div className="bg-purple/10 p-4 rounded-lg border border-purple/20">
                  <h3 className="font-medium text-purple-dark mb-2">Instructions:</h3>
                  <ol className="list-decimal pl-5 space-y-2 text-sm text-gray-700">
                    <li>Join our Discord server using the invite link below</li>
                    <li>Create a ticket in the server</li>
                    <li>Provide your payment details to buy coins</li>
                    <li>Our team will process your purchase</li>
                  </ol>
                </div>

                <div className="bg-gray-100 p-3 rounded-lg flex items-center justify-between">
                  <div className="truncate text-sm font-mono">{discordInvite}</div>
                  <Button variant="ghost" size="sm" className="ml-2" onClick={() => copyToClipboard(discordInvite)}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>

                <div className="text-sm text-gray-500 italic">
                  This invite link is automatically updated every 5 days
                </div>

                <div className="flex justify-center mt-2">
                  <Button
                    className="bg-[#5865F2] hover:bg-[#4752C4] text-white"
                    onClick={() => window.open(discordInvite, "_blank")}
                  >
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Open Discord
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-purple hover:bg-purple-dark text-white" onClick={() => router.push("/")}>
                Return to Home
              </Button>
            </CardFooter>
          </Card>
        ) : (
          <Card className="max-w-md mx-auto animate-glow bg-cream-light">
            <CardHeader className="bg-gradient-to-r from-purple to-purple-dark text-cream">
              <CardTitle className="text-center">Select Payment Method</CardTitle>
              <CardDescription className="text-center text-cream-light">
                Complete your purchase of {amount} coins for Rs {price}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <RadioGroup value={selectedMethod || ""} onValueChange={setSelectedMethod} className="space-y-4 mt-2">
                <div
                  className={`relative flex items-center rounded-lg border p-4 cursor-pointer transition-all ${selectedMethod === "google-play" ? "border-purple bg-purple/5" : "border-gray-200"}`}
                >
                  <RadioGroupItem value="google-play" id="google-play" className="peer sr-only" />
                  <Label htmlFor="google-play" className="flex items-center gap-4 cursor-pointer w-full">
                    <div className="w-12 h-12 relative flex items-center justify-center bg-white rounded-full">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" className="w-10 h-10">
                        <path
                          d="M325.3 234.3L104.6 13l280.8 161.2-60.1 60.1zM47 0C34 6.8 25.3 19.2 25.3 35.3v441.3c0 16.1 8.7 28.5 21.7 35.3l256.6-256L47 0zm425.2 225.6l-58.9-34.1-65.7 64.5 65.7 64.5 60.1-34.1c18-14.3 18-46.5-1.2-60.8zM104.6 499l280.8-161.2-60.1-60.1L104.6 499z"
                          fill="#EA4335"
                        />
                        <path d="M104.6 499l280.8-161.2-60.1-60.1L104.6 499z" fill="#FBBC04" />
                        <path d="M104.6 13l280.8 161.2-60.1 60.1L104.6 13z" fill="#4285F4" />
                        <path
                          d="M47 0C34 6.8 25.3 19.2 25.3 35.3v441.3c0 16.1 8.7 28.5 21.7 35.3l256.6-256L47 0z"
                          fill="#34A853"
                        />
                      </svg>
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Google Play Redeem Code</p>
                      <p className="text-sm text-gray-500">Pay using Google Play gift card</p>
                    </div>
                  </Label>
                </div>

                <div
                  className={`relative flex items-center rounded-lg border p-4 cursor-pointer transition-all ${selectedMethod === "amazon-pay" ? "border-purple bg-purple/5" : "border-gray-200"}`}
                >
                  <RadioGroupItem value="amazon-pay" id="amazon-pay" className="peer sr-only" />
                  <Label htmlFor="amazon-pay" className="flex items-center gap-4 cursor-pointer w-full">
                    <div className="w-12 h-12 relative flex items-center justify-center bg-white rounded-full">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" className="w-10 h-10">
                        <path
                          d="M257.2 162.7c-48.7 1.8-169.5 15.5-169.5 117.5 0 109.5 138.3 114 183.5 43.2 6.5 10.2 35.4 37.5 45.3 46.8l56.8-56S341 288.9 341 261.4V114.3C341 89 316.5 32 228.7 32 140.7 32 94 87 94 136.3l73.5 6.8c16.3-49.5 54.2-49.5 54.2-49.5 40.7-.1 35.5 29.8 35.5 69.1zm0 86.8c0 80-84.2 68-84.2 17.2 0-47.2 50.5-56.7 84.2-57.8v40.6zm136 163.5c-7.7 10-70 67-174.5 67S34.2 408.5 9.7 379c-6.8-7.7 1-11.3 5.5-8.3C88.5 415.2 203 488.5 387.7 401c7.5-3.7 13.3 2 5.5 12zm39.8 2.2c-6.5 15.8-16 26.8-21.2 31-5.5 4.5-9.5 2.7-6.5-3.8s19.3-46.5 12.7-55c-6.5-8.3-37-4.3-48-3.2-10.8 1-13 2-14-.3-2.3-5.7 21.7-15.5 37.5-17.5 15.7-1.8 41-.8 46 5.7 3.7 5.1 0 27.1-6.5 43.1z"
                          fill="#FF9900"
                        />
                      </svg>
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Amazon Pay Gift Card</p>
                      <p className="text-sm text-gray-500">Pay using Amazon Pay gift card</p>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full bg-purple hover:bg-purple-dark text-white"
                onClick={handlePayment}
                disabled={!selectedMethod || isProcessing}
              >
                {isProcessing ? "Processing Payment..." : "Complete Payment"}
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
      <Toaster />
    </main>
  )
}

