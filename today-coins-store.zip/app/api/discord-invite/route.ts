import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Access environment variables securely
    const apiKey = process.env.API_KEY
    const apiUrl = process.env.API_URL

    if (!apiKey || !apiUrl) {
      throw new Error("API credentials not configured")
    }

    // Fetch the Discord invite from the external API
    const response = await fetch(apiUrl, {
      headers: {
        Authorization: `Bearer ${apiKey}`,
      },
      cache: "no-store", // Ensure we always get fresh data
    })

    if (!response.ok) {
      throw new Error("Failed to fetch Discord invite")
    }

    const data = await response.json()

    // Return the Discord invite link
    return NextResponse.json({ inviteLink: data.inviteLink || "https://discord.gg/todaycoins" })
  } catch (error) {
    console.error("Error fetching Discord invite:", error)
    // Return a fallback invite link in case of error
    return NextResponse.json(
      { inviteLink: "https://discord.gg/todaycoins", error: "Could not fetch latest invite" },
      { status: 200 }, // Still return 200 with fallback link
    )
  }
}

