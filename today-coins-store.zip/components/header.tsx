import { Coins } from "lucide-react"

export function Header() {
  return (
    <header className="bg-gradient-to-r from-purple-dark to-purple shadow-lg">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-center">
          <Coins className="h-10 w-10 text-cream animate-bounce-slow mr-3" />
          <h1 className="text-3xl font-bold text-cream">Today Coins Store</h1>
        </div>
        <p className="text-center text-cream-light mt-2">Get the best deals on virtual coins</p>
      </div>
    </header>
  )
}

