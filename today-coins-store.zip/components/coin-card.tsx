"use client"

import { useState } from "react"
import { Coins } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"

interface CoinCardProps {
  amount: string
  price: number
}

export function CoinCard({ amount, price }: CoinCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const router = useRouter()

  const handlePurchase = () => {
    // Direct navigation to payment page with query parameters
    router.push(`/payment?amount=${amount}&price=${price}`)
  }

  return (
    <Card
      className={`overflow-hidden transition-all duration-300 ${isHovered ? "animate-glow scale-105" : "shadow-md"}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <CardHeader className="bg-gradient-to-r from-purple to-purple-dark text-cream">
        <CardTitle className="text-center text-2xl">{amount} COINS</CardTitle>
      </CardHeader>
      <CardContent className="p-6 bg-cream-light">
        <div className="flex justify-center mb-4">
          <div className={`${isHovered ? "animate-float" : ""} transition-all duration-300`}>
            <Coins className="h-16 w-16 text-purple" />
          </div>
        </div>
        <p className="text-center text-3xl font-bold text-purple-dark">Rs {price}</p>
        <p className="text-center text-purple-dark/70 mt-2">Premium virtual currency</p>
      </CardContent>
      <CardFooter className="bg-cream-light">
        <Button className="w-full bg-purple hover:bg-purple-dark text-white" onClick={handlePurchase}>
          Buy Now
        </Button>
      </CardFooter>
    </Card>
  )
}

